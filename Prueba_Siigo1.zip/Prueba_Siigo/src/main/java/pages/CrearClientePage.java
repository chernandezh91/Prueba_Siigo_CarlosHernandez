package pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CrearClientePage {
    private WebDriver driver;

    private By inputIdentificacion = By.id("//*[@id=\"identification\"]/input");
    private By inputNombres = By.id("//*[@id=\"sb68a66c-010a-4ce9-9b17-afe89646a010\"]");
    private By inputApellidos = By.id("//*[@id=\"sd7b8fdd-40a3-42e9-b1e1-c369bb65408a\"]");
    private By btnCrearCliente = By.id("//*[@id=\"sticky\"]/div[2]/button[2]");

    // Constructor
    public CrearClientePage(WebDriver driver) {
        this.driver = driver;
    }

    // Método para crear un cliente
    public void crearCliente(String identificacion, String nombres, String apellidos) {

        driver.findElement(inputIdentificacion).sendKeys(identificacion);

        driver.findElement(inputNombres).clear();
        driver.findElement(inputNombres).sendKeys(nombres);

        driver.findElement(inputApellidos).clear();
        driver.findElement(inputApellidos).sendKeys(apellidos);

        driver.findElement(btnCrearCliente).click();
    }
}