package stepDefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.en.*;
import pages.LoginPage;
import pages.CrearClientePage;
import java.util.List;
import io.cucumber.java.After;



public class CrearClienteSteps {

    WebDriver driver = new ChromeDriver();
    LoginPage loginPage = new LoginPage(driver);
    CrearClientePage crearClientePage = new CrearClientePage(driver);

    @Given("el usuario esta en login de la pagina")
    public void el_usuario_esta_en_login_de_la_pagina() {
        driver.get("https://qastaging.siigo.com/#/login/");
    }

    @When("se ingresa usuario y clave")
    public void se_ingresa_usuario_y_clave(List<List<String>> lstdata) {
        String usuario = lstdata.get(0).get(0);
        String clave = lstdata.get(0).get(1);

        // Llamamos al metodo para iniciar sesión
        loginPage.iniciarSesion(usuario,clave);
    }

    @When("se selecciona la opcion crear")
    public void se_selecciona_la_opcion_crear() {
        loginPage.clicBotonCrear();
    }

    @Then("se procede con la creacion del cliente")
        public void se_procede_con_la_creacion_del_cliente(List<List<String>> lstdata) {

            String identificacion = lstdata.get(0).get(0);
            String nombres = lstdata.get(0).get(1);
            String apellidos = lstdata.get(0).get(2);

            // Llamamos al método para crear el cliente
        crearClientePage.crearCliente(identificacion, nombres, apellidos);
        }


    @After
    public void closeBrowser() {
        driver.quit();
    }
}