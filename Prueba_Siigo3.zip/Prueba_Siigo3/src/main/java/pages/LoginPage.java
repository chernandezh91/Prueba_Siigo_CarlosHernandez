package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
    private WebDriver driver;

    private By inputUsuario = By.id("//*[@id=\"email\"]");
    private By inputClave = By.id("//*[@id=\"current-password\"]");
    private By btnIngresar = By.id("/html/body/flutter-view");
    private By btnCrear = By.id("//*[@id=\"wc-s5ec6e14-cf25-49c2-81fd-d4c0f614c7bc\"]/div");
    private By opcClientes = By.id("//*[@id=\"wc-s20ee9fa-da3f-44ba-9446-b12d9015a0fd\"]/header/nav/div/div[2]/ul/li[5]/siigo-header-create-button-dropdown/div/div[2]/div[1]/li[3]/div/a");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void iniciarSesion(String usuario, String clave) {
        driver.findElement(inputUsuario).sendKeys(usuario);
        driver.findElement(inputClave).sendKeys(clave);
        driver.findElement(btnIngresar).click();
    }

    public void clicBotonCrear() {
        // Localizar y hacer clic en el botón "Crear" y en la opción "Clientes" del menu desplegable
        driver.findElement(btnCrear).click();
        driver.findElement(opcClientes).click();

    }
}
