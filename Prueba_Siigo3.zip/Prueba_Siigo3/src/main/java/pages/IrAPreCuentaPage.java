package pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class IrAPreCuentaPage {
    private WebDriver driver;

    private By opcPreCuenta         = By.id("(//a[normalize-space()='Nueva pre-cuenta'])[1]");
    private By opcProducto          = By.id("(//a[normalize-space()='Productos'])[2]");
    private By opcProductoGenerico  = By.id("(//a[normalize-space()='Producto genérico'])[3]");
    private By btnCobrar            = By.id("(//a[normalize-space()='Guardar'])[4]");

    public IrAPreCuentaPage(WebDriver driver) {
        this.driver = driver;
    }

    public void cobrarValor() {

        driver.findElement(opcPreCuenta).click();
        driver.findElement(opcProducto).click();
        driver.findElement(opcProductoGenerico).click();
        driver.findElement(btnCobrar).click();
    }
}