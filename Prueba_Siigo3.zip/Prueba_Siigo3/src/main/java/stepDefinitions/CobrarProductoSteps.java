package stepDefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pages.LoginPage;
import pages.IrAPreCuentaPage;
import java.util.List;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;

public class CobrarProductoSteps {

    WebDriver driver = new ChromeDriver();
    LoginPage loginPage = new LoginPage(driver);
    IrAPreCuentaPage irAPreCuentaPage = new IrAPreCuentaPage(driver);

    @Given("el usuario esta en login de la pagina")
    public void el_usuario_esta_en_login_de_la_pagina() {
        driver.get("https://pos.qa.siigo.com/auth/login");
    }

    @When("se ingresa usuario y clave")
    public void se_ingresa_usuario_y_clave(List<List<String>> lstdata) {
        String usuario = lstdata.get(0).get(0);
        String clave = lstdata.get(0).get(1);

        // Llamamos al metodo para iniciar sesión
        loginPage.iniciarSesion(usuario,clave);
    }

    @Then("se procede con el cobro del producto generico")
        public void se_procede_con_el_cobro_del_producto_generico() {

            // Llamamos al método para ingresar al cobro de productos
        IrAPreCuentaPage.cobrarValor();
        }

    @After
    public void closeBrowser() {
        driver.quit();
    }
}